﻿namespace Fortress__Team_Project_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CardBox = new System.Windows.Forms.TextBox();
            this.LeftCard2 = new System.Windows.Forms.TextBox();
            this.RightCard3 = new System.Windows.Forms.TextBox();
            this.RightCard2 = new System.Windows.Forms.TextBox();
            this.LeftCard1 = new System.Windows.Forms.TextBox();
            this.LeftCard3 = new System.Windows.Forms.TextBox();
            this.RightCard1 = new System.Windows.Forms.TextBox();
            this.Base1 = new System.Windows.Forms.TextBox();
            this.Base2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.roundtxtbox = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(11, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(986, 42);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(98, 34);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(162, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(162, 34);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(162, 34);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(80, 4);
            // 
            // CardBox
            // 
            this.CardBox.BackColor = System.Drawing.Color.BurlyWood;
            this.CardBox.Location = new System.Drawing.Point(321, 391);
            this.CardBox.Margin = new System.Windows.Forms.Padding(6);
            this.CardBox.Name = "CardBox";
            this.CardBox.Size = new System.Drawing.Size(323, 29);
            this.CardBox.TabIndex = 8;
            this.CardBox.TextChanged += new System.EventHandler(this.CardBox_TextChanged);
            // 
            // LeftCard2
            // 
            this.LeftCard2.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard2.Location = new System.Drawing.Point(196, 249);
            this.LeftCard2.Margin = new System.Windows.Forms.Padding(6);
            this.LeftCard2.Name = "LeftCard2";
            this.LeftCard2.Size = new System.Drawing.Size(110, 29);
            this.LeftCard2.TabIndex = 1;
            this.LeftCard2.Leave += new System.EventHandler(this.LeftCard2_Leave_1);
            // 
            // RightCard3
            // 
            this.RightCard3.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard3.Location = new System.Drawing.Point(658, 319);
            this.RightCard3.Margin = new System.Windows.Forms.Padding(6);
            this.RightCard3.Name = "RightCard3";
            this.RightCard3.Size = new System.Drawing.Size(110, 29);
            this.RightCard3.TabIndex = 5;
            this.RightCard3.Leave += new System.EventHandler(this.RightCard3_Leave_1);
            // 
            // RightCard2
            // 
            this.RightCard2.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard2.Location = new System.Drawing.Point(658, 249);
            this.RightCard2.Margin = new System.Windows.Forms.Padding(6);
            this.RightCard2.Name = "RightCard2";
            this.RightCard2.Size = new System.Drawing.Size(110, 29);
            this.RightCard2.TabIndex = 4;
            this.RightCard2.Leave += new System.EventHandler(this.RightCard2_Leave_1);
            // 
            // LeftCard1
            // 
            this.LeftCard1.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard1.Location = new System.Drawing.Point(196, 179);
            this.LeftCard1.Margin = new System.Windows.Forms.Padding(6);
            this.LeftCard1.Name = "LeftCard1";
            this.LeftCard1.Size = new System.Drawing.Size(110, 29);
            this.LeftCard1.TabIndex = 0;
            this.LeftCard1.Leave += new System.EventHandler(this.LeftCard1_Leave_1);
            // 
            // LeftCard3
            // 
            this.LeftCard3.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard3.Location = new System.Drawing.Point(196, 319);
            this.LeftCard3.Margin = new System.Windows.Forms.Padding(6);
            this.LeftCard3.Name = "LeftCard3";
            this.LeftCard3.Size = new System.Drawing.Size(110, 29);
            this.LeftCard3.TabIndex = 2;
            this.LeftCard3.Leave += new System.EventHandler(this.LeftCard3_Leave_1);
            // 
            // RightCard1
            // 
            this.RightCard1.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard1.Location = new System.Drawing.Point(658, 179);
            this.RightCard1.Margin = new System.Windows.Forms.Padding(6);
            this.RightCard1.Name = "RightCard1";
            this.RightCard1.Size = new System.Drawing.Size(110, 29);
            this.RightCard1.TabIndex = 3;
            this.RightCard1.Leave += new System.EventHandler(this.RightCard1_Leave_1);
            // 
            // Base1
            // 
            this.Base1.BackColor = System.Drawing.Color.Green;
            this.Base1.Location = new System.Drawing.Point(42, 131);
            this.Base1.Margin = new System.Windows.Forms.Padding(6);
            this.Base1.Multiline = true;
            this.Base1.Name = "Base1";
            this.Base1.Size = new System.Drawing.Size(109, 34);
            this.Base1.TabIndex = 10;
            this.Base1.TextChanged += new System.EventHandler(this.Base1_TextChanged);
            // 
            // Base2
            // 
            this.Base2.BackColor = System.Drawing.Color.Green;
            this.Base2.Location = new System.Drawing.Point(805, 131);
            this.Base2.Margin = new System.Windows.Forms.Padding(6);
            this.Base2.Multiline = true;
            this.Base2.Name = "Base2";
            this.Base2.Size = new System.Drawing.Size(109, 34);
            this.Base2.TabIndex = 10;
            this.Base2.TextChanged += new System.EventHandler(this.Base2_TextChanged);
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Font = new System.Drawing.Font("Old English Text MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(422, 207);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 129);
            this.button1.TabIndex = 6;
            this.button1.Text = "Battle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 179);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 205);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(799, 179);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(165, 205);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(56, 100);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(831, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Player 2";
            // 
            // roundtxtbox
            // 
            this.roundtxtbox.BackColor = System.Drawing.Color.BurlyWood;
            this.roundtxtbox.Font = new System.Drawing.Font("Old English Text MT", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundtxtbox.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.roundtxtbox.Location = new System.Drawing.Point(415, 102);
            this.roundtxtbox.Multiline = true;
            this.roundtxtbox.Name = "roundtxtbox";
            this.roundtxtbox.Size = new System.Drawing.Size(156, 50);
            this.roundtxtbox.TabIndex = 24;
            this.roundtxtbox.Text = "Round: 1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(986, 534);
            this.Controls.Add(this.roundtxtbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Base1);
            this.Controls.Add(this.Base2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.RightCard1);
            this.Controls.Add(this.LeftCard3);
            this.Controls.Add(this.LeftCard1);
            this.Controls.Add(this.RightCard2);
            this.Controls.Add(this.RightCard3);
            this.Controls.Add(this.LeftCard2);
            this.Controls.Add(this.CardBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Fortress";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox CardBox;
        private System.Windows.Forms.TextBox LeftCard2;
        private System.Windows.Forms.TextBox RightCard3;
        private System.Windows.Forms.TextBox RightCard2;
        private System.Windows.Forms.TextBox LeftCard1;
        private System.Windows.Forms.TextBox LeftCard3;
        private System.Windows.Forms.TextBox RightCard1;
        private System.Windows.Forms.TextBox Base1;
        private System.Windows.Forms.TextBox Base2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox roundtxtbox;
    }
}

