﻿//Payton wrote this class with Bradon and Shawns help
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//user interaction
//Brandon Yates designed the user interfase design and developed and this code below
//I did not copy this code
//A4
//Test
namespace Fortress__Team_Project_
{
    public partial class Form1 : Form
    {
        numbers mynum = new numbers();
        bases mybase = new bases();


        public Form1()
        {
            InitializeComponent();
            //ADD SHAWNS CLASS CALL IT MYNUM: mynum
            mynum = new numbers();
            //ADD NATALIES CLASS CALL IT MYBASE: mybase
            mybase = new bases();
            Base2.Text = $"{baseone}";
            Base1.Text = $"{basetwo}";
            mynum.randonGen(ref cards);
            MessageBox.Show(" Welcome to Fortress! \n\n This game needs 2 players.\n You are both given the same hand.\n You choose the numbers and enter them into the boxes on your side.\n The higher numbers are more powerful.\n Their are 10 numbers 0-9.\n A 0 is special it reflects all the damage that you would take in that lane.\n If you have multiple of the same namber it deals more damage.\n For example their are two 3's you each 3 would have a value of 6!");

            CardBox.Text = $"            {cards[0]}    {cards[1]}    {cards[2]}     {cards[3]}     {cards[4]}     {cards[5]}";

            for(int i = 0; i < inputs.Length; i++)
            {
                inputs[i] = $"{i}";
            }
        }


        //Braden Wrote this code
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //shows the user who created the game
            MessageBox.Show("Created by: Brandon, Natalien, Payton, Shawn.\n\nThis game that is meant to be a balance between strategy and gussing.\n\nGood luck!");
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Exits the game
            this.Close();
        }
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //shows the user how to play the game
            MessageBox.Show(" This game needs 2 players.\n You are both given the same hand.\n You choose the numbers and enter them into the boxes on your side.\n The higher numbers are more powerful.\n Their are 10 numbers 0-9.\n A 0 is special it reflects all the damage that you would take in that lane.\n If you have multiple of the same namber it deals more damage.\n For example their are two 3's you each 3 would have a value of 6!");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            battle();
            startround();
            mynum.randonGen(ref cards);
            Base2.Text = $"{baseone}";
            Base1.Text = $"{basetwo}";
            CardBox.Text = $"            {cards[0]}    {cards[1]}    {cards[2]}     {cards[3]}     {cards[4]}     {cards[5]}";
            roundtxtbox.Text = $"Round: {roundcounter}";
        }



        //A list of all the variables we will need.
        int baseone = 50;
        int basetwo = 50;

        int roundcounter = 1;

        int[] cards = new int[6];
        int[] right = new int[3];
        int[] left = new int[3];
        int[] damage = numbers.Damage;
        int[] totalDamage = new int[2];
        string[] inputs = new string[10];


        //Payton Hall did this part
        //Brandon made sure that the names for the text boxes were correct
        //This method will clear all the text boxes and boards and things.
        //This method will refresh the numbers in each spot at the begining of each round.
        //It clears the boxes that need to be cleared and then sets the new numbers that have been calculated.
        public void startround()
        {
            mynum.randonGen(ref cards);
            //call this method to shawn:
            mynum.subtrack();

            for (int i = 0; i == cards.Length; i++)
            {
                cards[i] = 0;

            }
            for (int i = 0; i == right.Length; i++)
            {
                right[i] = 0;
                left[i] = 0;
            }

            //reset all data and colors to text box.


            LeftCard1.BackColor = Color.BurlyWood;
            LeftCard2.BackColor = Color.BurlyWood;
            LeftCard3.BackColor = Color.BurlyWood;
            RightCard1.BackColor = Color.BurlyWood;
            RightCard2.BackColor = Color.BurlyWood;
            RightCard3.BackColor = Color.BurlyWood;

            LeftCard1.Text = "";
            LeftCard2.Text = "";
            LeftCard3.Text = "";
            RightCard1.Text = "";
            RightCard2.Text = "";
            RightCard3.Text = "";

            CardBox.Text = "";

            roundcounter++;

            //set health each time
            //base1 and base2
            //The health will be updated at the end of each round.

            mybase.sendHealth(ref baseone, ref basetwo);

            Base2.Text = $"{baseone}";
            Base1.Text = $"{basetwo}";





            
        }

        //this method will be active once all the boxes have been inputed with correct numbers. 
        //Once that happens, all the boxes will be revealed, then the calculations will be sent to the numbers class.
        //Send numbers to shawn.
        //recieve numbers later.
        public void battle()
        {
            //when the button is clicked, run this:
            mynum.subtrack();
            mybase.damageGetter();
            mybase.subtractDamage();
            mybase.sendHealth(ref baseone, ref basetwo);
            bool check = mybase.checkHealth();
            mynum.passDamage(ref damage);
            for (int i = 0; i < 3; i++)
            {
                if (damage[i] < 0)
                {
                    totalDamage[0] += (damage[i] * -1);
                }
                else
                {
                    totalDamage[1] += damage[i];
                }
            }
            MessageBox.Show($"Player One took {totalDamage[1]} damage, and Player Two took {totalDamage[0]} damage.");
            totalDamage[1] -= totalDamage[1];
            totalDamage[0] -= totalDamage[0];

            if (!check)
            {
                if (baseone < 0)
                {
                    MessageBox.Show("Player Two won!Wow!Good Game!Thanks For Playing!!!");
                    roundcounter = -1;
                    startround();
                    mybase.reset();
                }
                else
                {
                    MessageBox.Show("Player One won!\nWow!Good Game!Thanks For Playing!!!");
                    roundcounter = -1;
                    startround();
                    mybase.reset();
                }
            }

            LeftCard1.Focus();
        }
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //THIS IS ALL THE CHECKING FOR EACH BOX
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //-----------------------------------------------------------
       

        private void LeftCard1_Leave_1(object sender, EventArgs e)
        {
            bool chekc = true;
            for(int i = 0; i < inputs.Length; i++)
            {
                if (LeftCard1.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            } 

            if (!chekc == true)
            {

                MessageBox.Show($"{LeftCard1.Text} is not one of the cards, try again.");
                LeftCard1.Clear();

                LeftCard1.Focus();


            }
            if (chekc)
            {
                chekc = mynum.leftValues(int.Parse(LeftCard1.Text), 0);



                if (chekc != true)
                {

                    MessageBox.Show($"{LeftCard1.Text} is not one of the cards, try again.");
                    LeftCard1.Clear();

                    LeftCard1.Focus();


                }
                else
                {
                    LeftCard1.BackColor = Color.Black;
                }
            }
        }

        private void LeftCard2_Leave_1(object sender, EventArgs e)
        {
            bool chekc = false;
            for (int i = 0; i < inputs.Length; i++)
            {
                if (LeftCard2.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            }

            if (!chekc == true)
            {

                MessageBox.Show($"{LeftCard2.Text} is not one of the cards, try again.");
                LeftCard2.Clear();

                LeftCard2.Focus();


            }
            if (chekc)
            {
                chekc = mynum.leftValues(int.Parse(LeftCard2.Text), 1);





                if (chekc != true)
                {

                    MessageBox.Show($"{LeftCard2.Text} is not one of the cards, try again.");
                    LeftCard2.Clear();

                    LeftCard2.Focus();


                }
                else
                {
                    LeftCard2.BackColor = Color.Black;
                }
            }
        }

        private void LeftCard3_Leave_1(object sender, EventArgs e)
        {
            bool chekc = false; 
            for (int i = 0; i < inputs.Length; i++)
            {
                if (LeftCard3.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            }

            if (!chekc == true)
            {

                MessageBox.Show($"{LeftCard3.Text} is not one of the cards, try again.");
                LeftCard3.Clear();

                LeftCard3.Focus();


            }

            if (chekc)
            {
                chekc = mynum.leftValues(int.Parse(LeftCard3.Text), 2);

                if (chekc != true)
                {

                    MessageBox.Show($"{LeftCard3.Text} is not one of the cards, try again.");
                    LeftCard3.Clear();

                    LeftCard3.Focus();


                }
                else
                {
                    LeftCard3.BackColor = Color.Black;
                }
            }
        }

        private void RightCard1_Leave_1(object sender, EventArgs e)
        {
            bool chekc = false;
            for (int i = 0; i < inputs.Length; i++)
            {
                if (RightCard1.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            }

            if (!chekc == true)
            {

                MessageBox.Show($"{RightCard1.Text} is not one of the cards, try again.");
                RightCard1.Clear();

                RightCard1.Focus();


            }

            if (chekc)
            {
                //When I leave the box, run this method.
                chekc = mynum.rightValues(int.Parse(RightCard1.Text), 0);





                if (chekc != true)
                {

                    MessageBox.Show($"{RightCard1.Text} is not one of the cards, try again.");
                    RightCard1.Clear();

                    RightCard1.Focus();


                }
                else
                {
                    RightCard1.BackColor = Color.Black;
                }
            }
        }

        private void RightCard2_Leave_1(object sender, EventArgs e)
        {
            //When I leave the box, run this method.
            bool chekc = false;
            for (int i = 0; i < inputs.Length; i++)
            {
                if (RightCard2.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            }

            if (!chekc == true)
            {

                MessageBox.Show($"{RightCard2.Text} is not one of the cards, try again.");
                RightCard2.Clear();

                RightCard2.Focus();


            }
            if (chekc)
            {
                chekc = mynum.rightValues(int.Parse(RightCard2.Text), 1);





                if (chekc != true)
                {

                    MessageBox.Show($"{RightCard2.Text} is not one of the cards, try again.");
                    RightCard2.Clear();

                    RightCard2.Focus();


                }
                else
                {
                    RightCard2.BackColor = Color.Black;
                }
            }
        }

        private void RightCard3_Leave_1(object sender, EventArgs e)
        {
            bool chekc = false;
            for (int i = 0; i < inputs.Length; i++)
            {
                if (RightCard3.Text == inputs[i])
                {
                    chekc = true;
                    break;
                }
                else
                    chekc = false;
            }

            if (!chekc == true)
            {

                MessageBox.Show($"{RightCard3.Text} is not one of the cards, try again.");
                RightCard3.Clear();

                RightCard3.Focus();


            }
            if (chekc)
            {
                chekc = mynum.rightValues(int.Parse(RightCard3.Text), 2);





                if (chekc != true)
                {

                    MessageBox.Show($"{RightCard3.Text} is not one of the cards, try again.");
                    RightCard3.Clear();

                    RightCard3.Focus();


                }
                else
                {
                    RightCard3.BackColor = Color.Black;
                }
            }
        }

        //crap that wasn't used
        private void RightCard3_Leave(object sender, EventArgs e)
        {


        }
        private void RightCard2_Leave(object sender, EventArgs e)
        {


        }
        private void RightCard1_Leave(object sender, EventArgs e)
        {


        }
        private void LeftCard3_Leave(object sender, EventArgs e)
        {

        }
        private void LeftCard2_Leave(object sender, EventArgs e)
        {


        }
        private void LeftCard1_Leave(object sender, EventArgs e)
        {

        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void CardBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void Base1_TextChanged(object sender, EventArgs e)
        {

        }
        private void Base2_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
