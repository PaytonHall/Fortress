﻿//The Base class was written by Natalie, and Shawn.
//Last Edited: April 25, 2017
//This code was not coped, this is all of my own code.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fortress__Team_Project_
{

    public class bases
    {
        numbers mynum = new numbers();
        const int BASE_HEALTH = 50;
        static int size = 3;
        int base1 = 50; //starts as 50, this is the total health for the left base
        int base2 = 50; //starts as 50, this is the total health for the right base
        int[] damage = numbers.Damage;

        //did not include a setter for damage becuase the subtractDamage method and setter were the same.

        //Method getter for damage
        //Name: damageGetter
        //Purpose: get the damage
        //parameters: direction and damage
        //Returns: damage
        public void damageGetter()
        {
            mynum.passDamage(ref damage);
        }


        //Method setter for damage
        //Name: damageSetter
        //Purpose: set the damage
        //Paramters: none
        //Returns: void
        public void subtractDamage()
        {
            for (int i = 0; i < size; i++)
            {

                if (damage[i] >= 0)
                {
                    base2 -= damage[i];
                }
                else
                {
                    base1 += damage[i];
                }
            }
        }//End subtractDamage


        //Method for checking health
        //Name: checkHealth
        //Purpose: to check if the health has reached zero
        //Parameters: leftBaseHealth, rightBaseHealth
        //Returns: bool
        public bool checkHealth()
        {
            //Variables
            bool health;
            //check health from both bases (variables base1 and base2)
            //if any of the health has reached zero send a bool
            //if the bool is true then the healths are not yet zero
            //if the bool is false then one of the healths are zero and the game needs to end
            if (base1 < 0)
            {
                health = false;
            }
            else if (base2 < 0)
            {
                health = false;
            }
            else
            {
                health = true;
            }

            //send the bool to payton 
            return health;

        }//End checkHealth


        //Method for sending total health after subtracting the damage
        //Name: sendHealth
        //Purpose: send the health to GUI class
        //Parameters: health
        //Returns: void
        public void sendHealth(ref int baseOne, ref int baseTwo)
        {
            baseOne = base1;
            baseTwo = base2;

        }//End sendHealth

        //reset this methood rest the base health
        //reset
        //parameters: none
        //returns: void
        public void reset()
        {
            base1 = BASE_HEALTH;
            base2 = BASE_HEALTH;
        }

    }
}