﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//user interaction
//Brandon Yates designed the user interfase design and developed and this code below
//I did not copy this code
//A4
//Test
namespace Fortress__Team_Project_
{
    public partial class Form1 : Form
    {
        numbers num;


        public Form1()
        {
            InitializeComponent();

            }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //shows the user who created the game
            MessageBox.Show("Created by: Brandon, Natalien, Payton, Shawn");
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Exits the game
            this.Close();
        }
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //shows the user how to play the game
            MessageBox.Show("The game needs 2 players.\n You are both given the same hand./n You choose the numbers and enter them into the boxes on your side./n The higher numbers are more powerful./n Their are 10 numbers 0-9./n A 0 is special it reflects all the damage that you would take in that lane./n If you have multiple of the same namber it deals more damage./n For example their are two 3's you each 3 would have a value of 6!");
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Base1_TextChanged(object sender, EventArgs e)
        {

        }



        private void Base2_TextChanged(object sender, EventArgs e)
        {

        }



        





        //Payton Hall
        //A list of all the variables we will need.
        int baseone = 50;
        int basetwo = 50;

        int onecard1;
        int onecard2;
        int onecard3;

        int twocard1;
        int twocard2;
        int twocard3;
        int cardBox;
        int roundcounter;

        int[] cards = new int[5];
        int[] right = new int[3];
        int[] left = new int[3];

        Random rnd = new Random();


        //Payton Hall did this part
        //Brandon made sure that the names for the text boxes were correct
        //This method will clear all the text boxes and boards and things.
        //This method will refresh the numbers in each spot at the begining of each round.
        //It clears the boxes that need to be cleared and then sets the new numbers that have been calculated.
        public void startround()
        {
            //call this method to shawn:
            mynum.subtract();





            for (int i = 0; i == cards.Length; i++)
            {
                cards[i] = 0;


            }
            for (int i = 0; i == right.Length; i++)
            {
                right[i] = 0;
                left[i] = 0;
            }

            //reset all data and colors to text box.


            LeftCard1.BackColor = Color.White;
            LeftCard2.BackColor = Color.White;
            LeftCard3.BackColor = Color.White;
            RightCard1.BackColor = Color.White;
            RightCard2.BackColor = Color.White;
            RightCard3.BackColor = Color.White;

            LeftCard1.Text = "";
            LeftCard2.Text = "";
            LeftCard3.Text = "";
            RightCard1.Text = "";
            RightCard2.Text = "";
            RightCard3.Text = "";

            CardBox.Text = "";

            roundcounter++;

            //set health each time
            //base1 and base2
            //The health will be updated at the end of each round.

            mybase.basehealth(ref baseone, ref basetwo);

            Base1.Text = $"{baseone}";
            Base2.Text = $"{basetwo}";




            //send test to natalie to see if anyone won1!
            if (mybase.Health() = false)
            {
                MessageBox.Show("Wow! Good Game! Thanks For Playing!!!");
                this.Close();


            }
        }


        //this method will be active once all the boxes have been inputed with correct numbers. 
        //Once that happens, all the boxes will be revealed, then the calculations will be sent to the numbers class.
        //Send numbers to shawn.
        //recieve numbers later.
        public void battle()
        {
            //when the button is clicked, run this:

        }
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //THIS IS ALL THE CHECKING FOR EACH BOX
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        //-----------------------------------------------------------
        private void RightCard3_Leave(object sender, EventArgs e)
        {
            bool chekc = mynum.rightValues(int.Parse(RightCard3.Text), 2);





            if (chekc != true)
            {

                MessageBox.Show($"{RightCard3.Text} is not one of the cards, try again.");
                RightCard3.Clear();

                RightCard3.Focus();


            }
            else
            {
                RightCard3.BackColor = Color.Black;
            }

        }
        private void RightCard2_Leave(object sender, EventArgs e)
        {
            //When I leave the box, run this method.

            bool chekc = mynum.rightValues(int.Parse(RightCard2.Text), 1);





            if (chekc != true)
            {

                MessageBox.Show($"{RightCard2.Text} is not one of the cards, try again.");
                RightCard2.Clear();

                RightCard2.Focus();


            }
            else
            {
                RightCard2.BackColor = Color.Black;
            }

        }
        private void RightCard1_Leave(object sender, EventArgs e)
        {
            //When I leave the box, run this method.
            bool chekc = mynum.rightValues(int.Parse(RightCard1.Text), 0);





            if (chekc != true)
            {

                MessageBox.Show($"{RightCard1.Text} is not one of the cards, try again.");
                RightCard1.Clear();

                RightCard1.Focus();


            }
            else
            {
                RightCard1.BackColor = Color.Black;
            }

        }
        private void LeftCard3_Leave(object sender, EventArgs e)
        {

        }
        private void LeftCard2_Leave(object sender, EventArgs e)
        {
            bool chekc = mynum.leftValues(int.Parse(LeftCard2.Text), 1);





            if (chekc != true)
            {

                MessageBox.Show($"{LeftCard2.Text} is not one of the cards, try again.");
                LeftCard2.Clear();

                LeftCard2.Focus();


            }
            else
            {
                LeftCard2.BackColor = Color.Black;
            }

        }
        private void LeftCard1_Leave(object sender, EventArgs e)
        {
            bool chekc = mynum.leftValues(int.Parse(LeftCard1.Text), 0);





            if (chekc != true)
            {

                MessageBox.Show($"{LeftCard1.Text} is not one of the cards, try again.");
                LeftCard1.Clear();

                LeftCard1.Focus();


            }
            else
            {
                LeftCard1.BackColor = Color.Black;
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
        
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void CardBox_TextChanged(object sender, EventArgs e)
        {

        }


    }

}
