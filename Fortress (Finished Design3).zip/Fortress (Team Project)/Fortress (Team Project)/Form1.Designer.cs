﻿namespace Fortress__Team_Project_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CardBox = new System.Windows.Forms.TextBox();
            this.LeftCard2 = new System.Windows.Forms.TextBox();
            this.RightCard3 = new System.Windows.Forms.TextBox();
            this.RightCard2 = new System.Windows.Forms.TextBox();
            this.LeftCard1 = new System.Windows.Forms.TextBox();
            this.LeftCard3 = new System.Windows.Forms.TextBox();
            this.RightCard1 = new System.Windows.Forms.TextBox();
            this.Base1 = new System.Windows.Forms.TextBox();
            this.Base2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(538, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // CardBox
            // 
            this.CardBox.BackColor = System.Drawing.Color.BurlyWood;
            this.CardBox.Location = new System.Drawing.Point(175, 212);
            this.CardBox.Multiline = true;
            this.CardBox.Name = "CardBox";
            this.CardBox.Size = new System.Drawing.Size(178, 65);
            this.CardBox.TabIndex = 4;
            this.CardBox.TextChanged += new System.EventHandler(this.CardBox_TextChanged);
            // 
            // LeftCard2
            // 
            this.LeftCard2.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard2.Location = new System.Drawing.Point(107, 135);
            this.LeftCard2.Name = "LeftCard2";
            this.LeftCard2.Size = new System.Drawing.Size(62, 20);
            this.LeftCard2.TabIndex = 8;
            // 
            // RightCard3
            // 
            this.RightCard3.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard3.Location = new System.Drawing.Point(359, 173);
            this.RightCard3.Name = "RightCard3";
            this.RightCard3.Size = new System.Drawing.Size(62, 20);
            this.RightCard3.TabIndex = 11;
            // 
            // RightCard2
            // 
            this.RightCard2.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard2.Location = new System.Drawing.Point(359, 135);
            this.RightCard2.Name = "RightCard2";
            this.RightCard2.Size = new System.Drawing.Size(62, 20);
            this.RightCard2.TabIndex = 15;
            // 
            // LeftCard1
            // 
            this.LeftCard1.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard1.Location = new System.Drawing.Point(107, 97);
            this.LeftCard1.Name = "LeftCard1";
            this.LeftCard1.Size = new System.Drawing.Size(62, 20);
            this.LeftCard1.TabIndex = 16;
            // 
            // LeftCard3
            // 
            this.LeftCard3.BackColor = System.Drawing.Color.BurlyWood;
            this.LeftCard3.Location = new System.Drawing.Point(107, 173);
            this.LeftCard3.Name = "LeftCard3";
            this.LeftCard3.Size = new System.Drawing.Size(62, 20);
            this.LeftCard3.TabIndex = 17;
            // 
            // RightCard1
            // 
            this.RightCard1.BackColor = System.Drawing.Color.BurlyWood;
            this.RightCard1.Location = new System.Drawing.Point(359, 97);
            this.RightCard1.Name = "RightCard1";
            this.RightCard1.Size = new System.Drawing.Size(62, 20);
            this.RightCard1.TabIndex = 18;
            // 
            // Base1
            // 
            this.Base1.BackColor = System.Drawing.Color.Green;
            this.Base1.Location = new System.Drawing.Point(23, 71);
            this.Base1.Multiline = true;
            this.Base1.Name = "Base1";
            this.Base1.Size = new System.Drawing.Size(61, 20);
            this.Base1.TabIndex = 19;
            this.Base1.TextChanged += new System.EventHandler(this.Base1_TextChanged);
            // 
            // Base2
            // 
            this.Base2.BackColor = System.Drawing.Color.Green;
            this.Base2.Location = new System.Drawing.Point(439, 71);
            this.Base2.Multiline = true;
            this.Base2.Name = "Base2";
            this.Base2.Size = new System.Drawing.Size(61, 20);
            this.Base2.TabIndex = 20;
            this.Base2.TextChanged += new System.EventHandler(this.Base2_TextChanged);
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Font = new System.Drawing.Font("Old English Text MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(230, 112);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 70);
            this.button1.TabIndex = 21;
            this.button1.Text = "Battle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(436, 97);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 111);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(30, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(445, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Player 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(538, 289);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Base1);
            this.Controls.Add(this.Base2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.RightCard1);
            this.Controls.Add(this.LeftCard3);
            this.Controls.Add(this.LeftCard1);
            this.Controls.Add(this.RightCard2);
            this.Controls.Add(this.RightCard3);
            this.Controls.Add(this.LeftCard2);
            this.Controls.Add(this.CardBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Fortress";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox CardBox;
        private System.Windows.Forms.TextBox LeftCard2;
        private System.Windows.Forms.TextBox RightCard3;
        private System.Windows.Forms.TextBox RightCard2;
        private System.Windows.Forms.TextBox LeftCard1;
        private System.Windows.Forms.TextBox LeftCard3;
        private System.Windows.Forms.TextBox RightCard1;
        private System.Windows.Forms.TextBox Base1;
        private System.Windows.Forms.TextBox Base2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

