﻿namespace Fortress__Team_Project_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.LeftCard2 = new System.Windows.Forms.TextBox();
            this.RightCard3 = new System.Windows.Forms.TextBox();
            this.RightCard2 = new System.Windows.Forms.TextBox();
            this.LeftCard1 = new System.Windows.Forms.TextBox();
            this.LeftCard3 = new System.Windows.Forms.TextBox();
            this.RightCard1 = new System.Windows.Forms.TextBox();
            this.Base1 = new System.Windows.Forms.TextBox();
            this.Base2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(501, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(164, 184);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(178, 65);
            this.textBox3.TabIndex = 4;
            // 
            // LeftCard2
            // 
            this.LeftCard2.Location = new System.Drawing.Point(96, 107);
            this.LeftCard2.Name = "LeftCard2";
            this.LeftCard2.Size = new System.Drawing.Size(62, 20);
            this.LeftCard2.TabIndex = 8;
            // 
            // RightCard3
            // 
            this.RightCard3.Location = new System.Drawing.Point(348, 145);
            this.RightCard3.Name = "RightCard3";
            this.RightCard3.Size = new System.Drawing.Size(62, 20);
            this.RightCard3.TabIndex = 11;
            // 
            // RightCard2
            // 
            this.RightCard2.Location = new System.Drawing.Point(348, 107);
            this.RightCard2.Name = "RightCard2";
            this.RightCard2.Size = new System.Drawing.Size(62, 20);
            this.RightCard2.TabIndex = 15;
            // 
            // LeftCard1
            // 
            this.LeftCard1.Location = new System.Drawing.Point(96, 69);
            this.LeftCard1.Name = "LeftCard1";
            this.LeftCard1.Size = new System.Drawing.Size(62, 20);
            this.LeftCard1.TabIndex = 16;
            // 
            // LeftCard3
            // 
            this.LeftCard3.Location = new System.Drawing.Point(96, 145);
            this.LeftCard3.Name = "LeftCard3";
            this.LeftCard3.Size = new System.Drawing.Size(62, 20);
            this.LeftCard3.TabIndex = 17;
            // 
            // RightCard1
            // 
            this.RightCard1.Location = new System.Drawing.Point(348, 69);
            this.RightCard1.Name = "RightCard1";
            this.RightCard1.Size = new System.Drawing.Size(62, 20);
            this.RightCard1.TabIndex = 18;
            // 
            // Base1
            // 
            this.Base1.Location = new System.Drawing.Point(0, 69);
            this.Base1.Multiline = true;
            this.Base1.Name = "Base1";
            this.Base1.Size = new System.Drawing.Size(61, 96);
            this.Base1.TabIndex = 19;
            // 
            // Base2
            // 
            this.Base2.Location = new System.Drawing.Point(428, 69);
            this.Base2.Multiline = true;
            this.Base2.Name = "Base2";
            this.Base2.Size = new System.Drawing.Size(61, 96);
            this.Base2.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(214, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 20);
            this.button1.TabIndex = 21;
            this.button1.Text = "Battle";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 261);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Base2);
            this.Controls.Add(this.Base1);
            this.Controls.Add(this.RightCard1);
            this.Controls.Add(this.LeftCard3);
            this.Controls.Add(this.LeftCard1);
            this.Controls.Add(this.RightCard2);
            this.Controls.Add(this.RightCard3);
            this.Controls.Add(this.LeftCard2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Fortress";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox LeftCard2;
        private System.Windows.Forms.TextBox RightCard3;
        private System.Windows.Forms.TextBox RightCard2;
        private System.Windows.Forms.TextBox LeftCard1;
        private System.Windows.Forms.TextBox LeftCard3;
        private System.Windows.Forms.TextBox RightCard1;
        private System.Windows.Forms.TextBox Base1;
        private System.Windows.Forms.TextBox Base2;
        private System.Windows.Forms.Button button1;
    }
}

